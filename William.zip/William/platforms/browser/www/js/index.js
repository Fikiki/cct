/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function() {
        app.receivedEvent('deviceready');
        tryingFile();
        requestFileSystem()
        //startWatch();
       // getLocation()
    },
    // Update DOM on a Received Event
    receivedEvent: function(id) {
        var parentElement = document.getElementById(id);
        var listeningElement = parentElement.querySelector('.listening');
        var receivedElement = parentElement.querySelector('.received');

        listeningElement.setAttribute('style', 'display:none;');
        receivedElement.setAttribute('style', 'display:block;');

        console.log('Received Event: ' + id);
    }
};




function shake(){
    navigator.vibrate(3000);
}



function accCallback(acceleration){
    var element = document.getElementById('accelerometer');
    
    element.innerHTML = 'Acceleration X: ' + acceleration.x + '<br>' +
                        'Acceleration Y: ' + acceleration.y + '<br>' +
                        'Acceleration Z: ' + acceleration.z + '<br>' +
                        'Timestamp: ' + acceleration.timestamp + '<br>';

}

// onError function used for all function if needed
function onError(message){
    console.log(message);
}

var options = {
    frequency: 3000
};

var watchID = null;

function startWatch(){
    watchID = navigator.accelerometer.watchAcceleration(accCallback, onError, options);    
}



function pics(){
    navigator.camera.getPicture(cameraCallback, onError);
}

function cameraCallback(imageData) {
    var image = document.getElementById('myImage');
    //image.src = "data:image/jpeg;base64," + imageData;
    image.src =  imageData;
}



//automatic converter using api
var http = new XMLHttpRequest();
const url = 'http://www.apilayer.net/api/live?access_key=295fa4ae6b0ad82f2deec9e1a75a6eda';
http.open("GET", url);
http.send();

http.onreadystatechange = (e) => {
    var response = http.responseText
    var responseJSON = JSON.parse(response);    
    var data = responseJSON.quotes;
    var keys = Object.keys(data);
    var quotesForView = "";

    keys.forEach((element) =>{
        quotesForView += "1 USD is equivalent to " + data[element] + " " + element + "<br>"; 
    });

    document.getElementById('conversion').innerHTML = quotesForView;

}

// ----------- GEOLOCATION

function getLocation(){
    navigator.geolocation.getCurrentPosition(geoCallback, onError); 
}

function geoCallback (position) {
    console.log(position);
    var lat = position.coords.latitude;
    var lng = position.coords.longitude;

    // RIGHT AFTER WE'VE GOT THE READING FROM THE GPS SENSOR
    // WE'RE CALLING THE OPENCAGE API WITH THE DATA COLLATED
    opencageapi(lat, lng);
    
    var loc = 'Latitude: '          + position.coords.latitude          + '<br>' +
          'Longitude: '         + position.coords.longitude         + '<br>' +
          'Altitude: '          + position.coords.altitude          + '<br>' +
          'Accuracy: '          + position.coords.accuracy          + '<br>' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '<br>' +
          'Heading: '           + position.coords.heading           + '<br>' +
          'Speed: '             + position.coords.speed             + '<br>' +
          'Timestamp: '         + position.timestamp                + '<br>';
    
     document.getElementById('location').innerHTML = loc;
    initMap2(lat,lng);

};

// ----------- GOOGLE MAPS API

// THIS IS THE ORIGINAL MAP
function initMap() {
    var uluru = {lat: -25.363, lng: 131.044};
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 4,
        center: uluru
    });
    var marker = new google.maps.Marker({
        position: uluru,
        map: map
    });
    var marker2 = new google.maps.Marker({
        position: {lat: -23.6993336, lng: 133.8713752},
        map: map
    });
    
}

// THIS IS A NEW MAP USING THE LOCATION FROM THE GPS SENSOR
function initMap2(lat, lng) {
    var pos = {lat: lat, lng: lng};
    var map = new google.maps.Map(document.getElementById('map'), {
        zoom: 18,
        center: pos
    });
    var marker = new google.maps.Marker({
        position: pos,
        map: map
    });

}

// file saving

function tryingFile(){

    // Displaying on console
    console.log(cordova.file);

    // Displaying on front end
    var toDisplay = "";
    toDisplay += "App Dir " + cordova.file.applicationDirectory + "<br>";
    toDisplay += "App Storage Dir " + cordova.file.applicationStorageDirectory + "<br>";
    toDisplay += "Cache Dir " + cordova.file.cacheDirectory + "<br>";
    toDisplay += "Data Dir " + cordova.file.dataDirectory + "<br>";
    toDisplay += "Doc Dir " + cordova.file.documentsDirectory + "<br>";
    toDisplay += "Ext Cache Dir " + cordova.file.externalCacheDirectory + "<br>";
    toDisplay += "Ext Data Dir " + cordova.file.externalDataDirectory + "<br>";
    toDisplay += "Ext Root Dir " + cordova.file.externalRootDirectory + "<br>";
    toDisplay += "Shared Dir " + cordova.file.sharedDirectory + "<br>";
    toDisplay += "Temp Dir " + cordova.file.tempDirectory + "<br>";
    document.getElementById('file').innerHTML = toDisplay;

    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, fileSystemCallback, onError);
   
}

function fileSystemCallback(fs){
    // Displaying result in the console
    console.log('file system open: ' + fs.name);

    // Displaying in front end
    //var toFronEnd = 'file system open: ' + fs.name;
    //document.getElementById('file').innerHTML = toFronEnd;

    // Name of the file I want to create
    var fileToCreate = "newPersistentFile.txt";

    // Opening/creating the file
    fs.root.getFile(fileToCreate, fileSystemOptionals, getFileCallback, onError);
}

var fileSystemOptionals = { create: true, exclusive: false };

function getFileCallback(fileEntry){
    // Display in the console
    console.log("fileEntry is file?" + fileEntry.isFile.toString());

    // Displaying in front end
    // var toFrontEnd = document.getElementById('file').innerHTML;
    // toFrontEnd += "fileEntry is file?" + fileEntry.isFile.toString();
    // document.getElementById('file').innerHTML = toFrontEnd;
    
    var dataObj = new Blob(['Hiyaaaaa'], { type: 'text/plain' });
    // Now decide what to do
    // Write to the file
   // writeFile(fileEntry, dataObj);

    // Or read the file
    readFile(fileEntry);
}

// Let's write some files
function writeFile(fileEntry, dataObj) {

    // Create a FileWriter object for our FileEntry (log.txt).
    fileEntry.createWriter(function (fileWriter) {

        // If data object is not passed in,
        // create a new Blob instead.
        if (!dataObj) {
            dataObj = new Blob(['Lets write some text here'], { type: 'text/plain' });
        }

        fileWriter.write(dataObj);

        fileWriter.onwriteend = function() {
            console.log("Successful file write...");
        };

        fileWriter.onerror = function (e) {
            console.log("Failed file write: " + e.toString());
        };


    });
}


// Let's read some files
function readFile(fileEntry) {

    // Get the file from the file entry
    fileEntry.file(function (file) {
        
        // Create the reader
        var reader = new FileReader();
        reader.readAsText(file);

        reader.onloadend = function() {

            console.log("Successful file read: " + this.result);
            console.log("file path: " + fileEntry.fullPath);

        };

    }, onError);
}

// opencage api

function opencageapi(lat, lng) {

    var http = new XMLHttpRequest();
    const opencage = 'https://api.opencagedata.com/geocode/v1/json?q=' + lat + '+' + lng + '&key=22e5695431c543d682e4d4b52ec743ab';
    http.open("GET", opencage);
    http.send();

    http.onreadystatechange = (e) => {
        var response = http.responseText;
        var responseJSON = JSON.parse(response);    
        console.log(responseJSON);
        
        var country = responseJSON.results[0].components.country;  
        console.log(country);

        var city = responseJSON.results[0].components.city;    
        console.log(city);

        var currency = responseJSON.results[0].annotations.currency.iso_code;    
        console.log(currency);
        getRate(currency);
    }

}

var rate;

// THIS FUNCTION IS CALLED WHEN THE LOCATION 
// IS OBTAINED FROM THE GPS SENSOR AND THE OPENCAGE API
// HAS SENT ITS RESPONSE
function getRate(currency){
    var http = new XMLHttpRequest();
    const url = 'http://www.apilayer.net/api/live?access_key=295fa4ae6b0ad82f2deec9e1a75a6eda&currencies='+currency;
    http.open("GET", url);
    http.send();

    http.onreadystatechange = (e) => {
        var response = http.responseText
        var responseJSON = JSON.parse(response);    
        console.log(responseJSON);
        var tag = "USD"+currency;
        rate = responseJSON.quotes[tag];
        console.log(rate);
    }
}
// currency conversion happens here

// from USD to local

function convertToLocalCurrency(){
    var amount = document.getElementById('usd').value;
    var converted = amount * rate;
    document.getElementById('local').value = converted;
}

// Local to USD
function convertFromLocalCurrency(){
    var amount = document.getElementById('local').value;
    var converted = amount / rate;
    document.getElementById('usd').value = converted;

}



//weather of a city is shown
 function getWeather(lat, lon) {
   $.ajax({
     url: "https://api.darksky.net/forecast/9c4e8944261ed3b6f5f3438431a5cfa0/" + lat + "," + lon,
     dataType: "jsonp",
     success: function(data) {
       console.log("Current temp: " + data.currently.temperature);
       // get all the information
       var fahrenheit = data.currently.temperature.toFixed(2),
         locationName = data.timezone,
         splice = locationName.indexOf("/"),
         icon = data.currently.icon.toUpperCase()
       console.log(icon)
       console.log(splice)
         //apparently the temperature is returned in kelvin, so we need to quickly convert it to celsius, which gives a horrible number so is rounded to two decimal places. 
       var celsius = ((fahrenheit - 32) * 5 / 9).toFixed(2); 
       console.log(celsius); // Wh
       $("#tempC").html(celsius + "&deg;C");
       $("#locationName").html(locationName.substring(splice + 1).replace("_", " "));
       $("#tempF").html(fahrenheit + "&deg;F").hide();

       $("#toggle").click(function() {
         $("#tempC").toggle("slow")
         $("#tempF").toggle("slow")
       });
       var icons = new Skycons({
         "color": "white"
       });
       icons.set("icon", icon)
       icons.play();
     }
   });
 }

 // Gets the users position 
 if (navigator.geolocation) { 
   navigator.geolocation.getCurrentPosition(function(position) {
     $("#data").html("latitude: " + position.coords.latitude + "<br>longitude: " + position.coords.longitude);
     var lat = position.coords.latitude;
     var lon = position.coords.longitude;
     getWeather(lat, lon);
   });
 }
